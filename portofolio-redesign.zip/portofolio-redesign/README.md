# ARRAHMAN — Portfolio Redesign 🚀

Web portofolio yang telah di-redesign total dengan tema **Dark & Modern Cyberpunk**.

## Fitur Baru
- 🌑 **Dark/Light mode toggle** — tersimpan otomatis di browser
- 🎬 **Loading screen** dengan animasi bar
- 🖱️ **Custom cursor** neon dengan efek smooth ring
- 🌊 **Scroll reveal animations** — elemen muncul saat discroll
- 🃏 **Profile card** dengan border neon & scanline effect
- 🎨 **Glassmorphism** navbar dengan blur effect
- ✨ **Neon glow** & glitch effect pada logo

## File
- `index.html` — Halaman Biodata
- `sertifikat.html` — Halaman Sertifikat & Tugas Axioo
- `styles.css` — Semua styling
- `script.js` — Semua interaktivitas

## Cara Pakai
1. Letakkan semua file dalam satu folder
2. Buka `index.html` di browser
3. Tidak perlu server — bisa langsung dibuka!
